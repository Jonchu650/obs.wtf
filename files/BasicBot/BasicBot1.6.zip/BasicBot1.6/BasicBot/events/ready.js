module.exports = (client) => { // get the client from the index

    console.log(`The bot has started, logged in as ${client.user.tag}.`); // log in the console that the bot has started
    
    
    }