module.exports = (client, message) => { // define the client and get the message sent
    // ignore messages sent by other bots
    if (message.author.bot) return;
    
    // get our prefix from the config file
    let prefix = client.config.prefix; 
     // ignore messages that do not start with our prefix
       if (!message.content.startsWith(prefix)) return;
     // define our arguments in the command
       const args = message.content.slice(prefix.length).trim().split(/ +/g);
      // define the name of our command
        const command = args.shift().toLowerCase();
     
       // grab the command data from the client.commands Map
       const cmd = client.commands.get(command);
     
       // if that command doesn't exist, silently exit and do nothing
       if (!cmd) return;  
   
       // run the command
       cmd.run(client, message, args);
   
   };