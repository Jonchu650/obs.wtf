module.exports = async (client) => {
client.em = function (author, description, color, title, footer, nolenny) {
    if (!color) color = "RANDOM";
    if (!author) author = client.user.tag;
    if (author && !nolenny) author = author + ` ${client.lenny()}`
            let embed = new Discord.MessageEmbed()
    .setAuthor(author, client.user.displayAvatarURL())
    .setColor(color);
    
    if (title) embed.setTitle(title);
    
    if (description) embed.setDescription(description);
    
    if (footer) embed.setFooter(footer);
    
    return embed;
    
        }
    
    
    client.yessir = function(value){
    if (!value) return "No";
    if (typeof value === "object" || typeof value === "array") {
        if (!value.length || !value.length <= 0) return "No";
        else return "Yes";
    }
    
    if (typeof value === "boolean") {
        if (value === true) return "Yes";
        if (value === false || value === null || value === undefined) return "No";
    }
    
        if (typeof value === "number") {
        if (!~value || value === 0) return "No";
        else return "Yes";
    }
    
    return "No";
    
    }
}