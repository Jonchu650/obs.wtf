const Discord = require('discord.js');
const { MessageEmbed } = require('discord.js');
module.exports.run = async(client, message, args) => {
    const em = client.em;
    const yessir = client.yessir;
    const config = client.config;

    async function showCommand(commandName){
        if (!client.commands.get(commandName)) return message.channel.send(em("Command Not Found", "This command does not exist.", "#7a1b07"));
    let command = client.commands.get(commandName);
    if (command.help.hidden) return message.channel.send(em("Command Not Found", "This command does not exist.", "#7a1b07"));    
    let embed = new MessageEmbed()
    .setAuthor(command.help.name, client.user.avatarURL())
    .setColor("RANDOM")
    .setDescription(command.help.description);
    
    if (command.help.usage.length > 0) embed.addField("Usage", `\`\`\`${config.prefix}${command.help.name} ${command.help.usage}\`\`\``);
    
    embed.addField("Aliases", command.help.aliases);

    embed.addField("Enabled", yessir(command.help.enabled));

message.channel.send(embed);

return;    
    }

    async function showMenu(){
        let embed = new MessageEmbed()
        .setAuthor('Help Menu', client.user.avatarURL())
        .setDescription(`Description.
This server's prefix is \`${config.prefix}\``)
.setColor("RANDOM")
.setFooter('Created by OBS#9231');

if (client.commands.length > 25) return;


await client.commands.forEach(cmd => {
    if (cmd.help.hidden) return;
    if (cmd.help.isAlias) return;
embed.addField(`${cmd.help.name} **Usage:** \`${config.prefix}${cmd.help.name} ${cmd.help.usage}\``);
})

message.channel.send(embed);
return;
    }

    args[0] ? showCommand(args[0]) : showMenu();

}
module.exports.help = {
    name: "help",
    description: "Displays the help page.",
    enabled: true,
    aliases: "commands",
    usage: "[command]"
}