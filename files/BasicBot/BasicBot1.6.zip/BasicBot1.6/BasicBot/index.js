/* Hey there! Thanks for using my pre-made discord package. (OBS)
Make sure you read the docs and change anything to your needs.
Have fun developing! Good luck from me, OBS! */

require('dotenv').config();

const Discord = require("discord.js"); // define our discord library
const client = new Discord.Client(); // create a client (the bot itself)
const config = require("./config.json"); // define the config file we made
const fs = require("fs") // define fs to manage files
const Enmap = require("enmap"); // define enmap to hold command names and files

fs.readdir("./events/", (err, files) => { // get all of our event scripts we will create in the future.
    if (err) return console.error(err); // if we cannot get them log in the console why
    files.forEach(file => { // do the following for every file
      const event = require(`./events/${file}`); // define the events file
      let eventName = file.split(".")[0]; // remove .js from the file name
      client.on(eventName, event.bind(null, client)); // when the event happens run the file
    });
  });

  client.commands = new Enmap(); // create a new Map() to keep our commands

  fs.readdir("./commands/", (err, files) => { // get all of our commands we will have made in the future
    if (err) return console.error(err); // if they cannot be found log in the console why
    files.forEach(file => { // do the following for every command
      if (!file.endsWith(".js")) return; // if the command is not javascript ignore it
      let props = require(`./commands/${file}`); // define the file of the command
      let commandName = file.split(".")[0]; // remove .js from the file name
      console.log(`Loaded ${commandName}`); // log that we have loaded this command
      client.commands.set(commandName, props); // save this command into our map
    });
  });
  

require('./utils/functions.js')(client);


  client.config = config; // define our config to use everywhere

client.login(process.env.TOKEN);