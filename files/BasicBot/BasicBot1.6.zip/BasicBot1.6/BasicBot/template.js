const Discord = require("discord.js");
const { MessageEmbed } = require('discord.js');

exports.run = async (client, message, args) => {
    const em = client.em;
    const yessir = client.yessir;

    /* Your commands code goes right here. */
    
}
exports.help = {
    name: "",
    description: "",
    enabled: true,
    aliases: "",
    usage: ""
}